#Requires -Version 5.1
<#
  1. Genere assets/loupgarou/sounds.json : pour chaque son du jeu, utilise ton
     fichier .ogg s'il existe (assets/loupgarou/sounds/<categorie>/<nom>.ogg,
     plus d'eventuelles variantes <nom>_2.ogg, <nom>_3.ogg... jouees au hasard),
     sinon un son vanilla de remplacement.
  2. Empaquette resourcepack/ en resourcepack.zip et affiche son SHA1.
  A relancer a chaque fois qu'une texture, un modele ou un son change.
#>
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$texturesDir = Join-Path $root "assets\minecraft\textures\item"
$soundsDir = Join-Path $root "assets\loupgarou\sounds"

# ---------------------------------------------------------------------------
# 1. sounds.json
# Cle du son (utilisee par le plugin, voir Sfx.java) -> son vanilla de remplacement
# (+ hauteur du son de remplacement). Le fichier perso attendu pour "jour.aube"
# est assets/loupgarou/sounds/jour/aube.ogg.
# ---------------------------------------------------------------------------
$sounds = [ordered]@{
    "partie.debut"            = @("minecraft:event.raid.horn", 1.0)
    "partie.victoire_village" = @("minecraft:ui.toast.challenge_complete", 1.0)
    "partie.victoire_loups"   = @("minecraft:entity.wolf.howl", 0.7)
    "partie.fin"              = @("minecraft:ui.toast.challenge_complete", 0.8)
    "nuit.tombe"              = @("minecraft:block.beacon.deactivate", 0.6)
    "nuit.hurlement"          = @("minecraft:entity.wolf.howl", 0.8)
    "nuit.ambiance"           = @("minecraft:ambient.cave", 1.0)
    "nuit.appel"              = @("minecraft:block.amethyst_block.chime", 1.0)
    "jour.aube"               = @("minecraft:entity.chicken.ambient", 0.8)
    "jour.reveil"             = @("minecraft:block.bell.resonate", 1.0)
    "mort.tension"            = @("minecraft:entity.warden.heartbeat", 1.0)
    "mort.revelation"         = @("minecraft:block.bell.use", 0.5)
    "mort.aucune"             = @("minecraft:block.beacon.activate", 1.2)
    "vote.debut"              = @("minecraft:item.goat_horn.sound.0", 1.0)
    "vote.accusation"         = @("minecraft:entity.villager.no", 0.6)
    "vote.verdict"            = @("minecraft:block.anvil.land", 0.8)
    "vote.capitaine"          = @("minecraft:ui.toast.challenge_complete", 1.0)
    "minuteur.tic"            = @("minecraft:block.note_block.hat", 1.0)
}

$entries = @()
$custom = @()
foreach ($key in $sounds.Keys) {
    $parts = $key.Split(".")
    $folder = Join-Path $soundsDir $parts[0]
    $base = $parts[1]
    $files = @()
    if (Test-Path $folder) {
        $files = @(Get-ChildItem -Path $folder -Filter "*.ogg" -File |
                Where-Object { $_.BaseName -eq $base -or $_.BaseName -match ("^" + [regex]::Escape($base) + "_\d+$") } |
                Sort-Object Name)
    }
    if ($files.Count -gt 0) {
        $names = $files | ForEach-Object { '"loupgarou:' + $parts[0] + '/' + $_.BaseName + '"' }
        $entries += ('  "' + $key + '": { "sounds": [' + ($names -join ", ") + '] }')
        $custom += "$key ($($files.Count) fichier(s))"
    } else {
        $vanilla = $sounds[$key][0]
        $pitch = [string]::Format([System.Globalization.CultureInfo]::InvariantCulture, "{0}", $sounds[$key][1])
        $entries += ('  "' + $key + '": { "sounds": [{ "name": "' + $vanilla + '", "type": "event", "pitch": ' + $pitch + ' }] }')
    }
}
$soundsJson = "{`n" + ($entries -join ",`n") + "`n}`n"
New-Item -ItemType Directory -Force (Split-Path $soundsDir) | Out-Null
[System.IO.File]::WriteAllText((Join-Path (Split-Path $soundsDir) "sounds.json"), $soundsJson, (New-Object System.Text.UTF8Encoding($false)))

if ($custom.Count -gt 0) {
    Write-Host "Sons personnalises utilises :" -ForegroundColor Green
    foreach ($c in $custom) { Write-Host "  - $c" -ForegroundColor Green }
} else {
    Write-Host "Aucun son personnalise trouve : sons vanilla de remplacement partout (voir README.md)." -ForegroundColor Yellow
}
Write-Host ""

# ---------------------------------------------------------------------------
# 2. Verification des textures
# ---------------------------------------------------------------------------
$expected = @(
    "role_capitaine", "role_chasseur", "role_corbeau", "role_cupidon", "role_idiot",
    "role_infectpere", "role_loup", "role_loupblanc", "role_petitefille", "role_salvateur",
    "role_sorciere", "role_villageois", "role_voleur", "role_voyante", "role_juge"
)
Add-Type -AssemblyName System.Drawing
foreach ($name in $expected) {
    $path = Join-Path $texturesDir "$name.png"
    if (-not (Test-Path $path)) {
        Write-Host "Texture manquante : $name.png" -ForegroundColor Yellow
        continue
    }
    $img = [System.Drawing.Image]::FromFile($path)
    $w = $img.Width; $h = $img.Height
    $img.Dispose()
    # Une taille qui n'est pas une puissance de 2 (ex: 785x785) desactive les
    # mipmaps de TOUT le jeu pour les joueurs qui ont le pack (scintillement au loin).
    if (($w -band ($w - 1)) -ne 0 -or ($h -band ($h - 1)) -ne 0) {
        Write-Host "Attention : $name.png fait ${w}x${h} - utilise une puissance de 2 (256, 512...)." -ForegroundColor Yellow
    }
}

# ---------------------------------------------------------------------------
# 3. Zip (chemins avec des slashs, comme l'impose la norme ZIP - Compress-Archive
#    met des anti-slashs sur Windows, ce qui cassait certains fichiers du pack)
# ---------------------------------------------------------------------------
$zipPath = Join-Path (Split-Path -Parent $root) "resourcepack.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$filesToZip = @(Join-Path $root "pack.mcmeta")
$filesToZip += Get-ChildItem -Path (Join-Path $root "assets") -Recurse -File | ForEach-Object { $_.FullName }

$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $filesToZip) {
        $entryName = $file.Substring($root.Length + 1) -replace '\\', '/'
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file, $entryName, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
}
finally {
    $zip.Dispose()
}

$hash = (Get-FileHash -Path $zipPath -Algorithm SHA1).Hash.ToLower()
$sizeMb = "{0:N1}" -f ((Get-Item $zipPath).Length / 1MB)

Write-Host ""
Write-Host "Pack cree : $zipPath ($sizeMb Mo)" -ForegroundColor Green
Write-Host "SHA1      : $hash" -ForegroundColor Green
Write-Host ""
Write-Host "Ensuite, AU CHOIX :" -ForegroundColor Cyan
Write-Host " A) Heberge ce zip (lien DIRECT) et mets son URL dans plugins/LoupGarouRPS/config.yml" -ForegroundColor Cyan
Write-Host "    > resource-pack.url, puis tape /lg pack en jeu. Le plugin calcule le SHA1 tout seul." -ForegroundColor Cyan
Write-Host " B) Copie ce zip dans plugins/LoupGarouRPS/ (le plugin le sert lui-meme, voir serveur-http)." -ForegroundColor Cyan
Write-Host " Dans les deux cas, VIDE resource-pack= et resource-pack-sha1= dans server.properties." -ForegroundColor Cyan
