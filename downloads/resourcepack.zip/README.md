# Resource pack Loup-Garou RPS

Contient les **cartes de rôles** (textures + modèles) et les **sons d'ambiance**
du jeu. Après toute modification (texture, modèle, son), relance
`package.ps1` : il régénère `assets/loupgarou/sounds.json`, vérifie les
textures et recrée `resourcepack.zip` à la racine du projet.

## Envoi aux joueurs (important : bug de la carte du Juge)

Le client Minecraft garde le pack d'un serveur en cache **sous le nom de son
URL**. Si tu remplaces le zip à la même URL sans changer `resource-pack-sha1`
dans `server.properties`, les joueurs gardent l'ancien pack sans rien dire :
c'est ce qui faisait afficher la carte d'un autre rôle à la place du Juge (dans
l'ancien pack, la carte 116 n'existait pas encore).

Désormais c'est le plugin qui envoie le pack, avec le bon SHA1 calculé tout
seul et une URL qui change dès que le zip change :

1. Lance `package.ps1`.
2. Au choix :
   - **A — hébergement externe** : mets `resourcepack.zip` en ligne avec un lien
     **direct** (GitHub Release, mc-packs.net...), colle ce lien dans
     `plugins/LoupGarouRPS/config.yml` > `resource-pack.url`.
   - **B — le plugin l'héberge** : copie `resourcepack.zip` dans
     `plugins/LoupGarouRPS/`, laisse `resource-pack.url` vide et renseigne
     `serveur-http.adresse-publique` (+ ouvre le port `serveur-http.port`).
3. **Vide** `resource-pack=` et `resource-pack-sha1=` dans `server.properties`.
4. En jeu : `/lg pack` (renvoie le pack à tout le monde, pas besoin de redémarrer).

Refais `package.ps1` + (ré-upload ou recopie) + `/lg pack` à chaque changement.

## Sons

Le plugin joue des sons `loupgarou:...`. Tant que tu ne fournis pas de fichier,
chacun pointe vers un son vanilla de remplacement (colonne « actuel »). Pour
mettre le tien, dépose un `.ogg` au chemin indiqué puis relance `package.ps1` :
il le détecte tout seul. Plusieurs variantes jouées au hasard :
`ambiance.ogg`, `ambiance_2.ogg`, `ambiance_3.ogg`...

On ne remplace **pas** les sons vanilla eux-mêmes : remplacer la cloche
vanilla changerait aussi toutes les cloches du monde, lobby compris.

| Fichier à déposer dans `assets/loupgarou/sounds/` | Quand | Son actuel | Idée de remplacement |
|---|---|---|---|
| `partie/debut.ogg` | Lancement de la partie | cor de raid | cor/tambour de village |
| `nuit/tombe.ogg` | « La nuit tombe... » | balise qui s'éteint | gong grave, vent qui se lève |
| `nuit/hurlement.ogg` | Le monde s'assombrit | hurlement de loup | hurlement de loup lointain |
| `nuit/ambiance.ogg` | Toutes les 18-32 s la nuit | ambiance de grotte | grillons, chouette, vent (5-15 s) |
| `nuit/appel.ogg` | C'est ton tour de jouer ton rôle | carillon d'améthyste | clochette douce, chuchotement |
| `jour/aube.ogg` | Le soleil se lève | poule | **chant du coq** |
| `jour/reveil.ogg` | « Le village se réveille » | cloche (résonance) | cloche d'église, oiseaux |
| `mort/tension.ogg` | Bûcher avant l'éclair (répété) | battement du Warden | battement de cœur court (< 1 s) |
| `mort/revelation.ogg` | Révélation du rôle d'un mort | cloche grave | glas, accord dramatique |
| `mort/aucune.ogg` | Personne n'est mort cette nuit | balise qui s'allume | accord de soulagement |
| `vote/debut.ogg` | Ouverture d'un vote | corne de chèvre | cor d'appel, brouhaha de foule |
| `vote/accusation.ogg` | Quelqu'un vote contre quelqu'un | « hmm » de villageois | « Coupable ! », murmure de foule |
| `vote/verdict.ogg` | Condamnation | enclume | coup de marteau de juge |
| `vote/capitaine.ogg` | Capitaine élu | fanfare de succès | fanfare, acclamations |
| `minuteur/tic.ogg` | 5 dernières secondes d'un vote | charleston | tic d'horloge |
| `partie/victoire_village.ogg` | Victoire du village | fanfare de succès | fanfare victorieuse |
| `partie/victoire_loups.ogg` | Victoire des loups / Loup Blanc | hurlement grave | meute qui hurle |
| `partie/fin.ogg` | Autres fins (amoureux, Idiot, arrêt) | fanfare de succès | musique de fin |

Format : **Ogg Vorbis (.ogg), mono**, 44,1 kHz (un fichier stéréo ne serait pas
spatialisé). Avec Audacity : *Pistes > Mixer > Mixer stéréo vers mono*, puis
*Fichier > Exporter > Exporter en OGG*. Noms de fichiers en minuscules, sans
accent ni espace.

## Cartes de rôles

Chaque carte est un `PAPER` avec un `CustomModelData` (voir `RoleType` côté
plugin), relié ici à son modèle par `models/item/paper.json`. Les deux doivent
rester synchronisés.

| CustomModelData | Rôle | Texture |
|---:|---|---|
| 101 | Capitaine | `role_capitaine.png` |
| 102 | Chasseur | `role_chasseur.png` |
| 103 | Corbeau | `role_corbeau.png` |
| 104 | Cupidon | `role_cupidon.png` |
| 105 | Idiot | `role_idiot.png` |
| 106 | Infect Père des Loups | `role_infectpere.png` |
| 107 | Loup-Garou | `role_loup.png` |
| 108 | Loup Blanc | `role_loupblanc.png` |
| 109 | Petite Fille | `role_petitefille.png` |
| 110 | Salvateur | `role_salvateur.png` |
| 111 | Sorcière | `role_sorciere.png` |
| 112 | Villageois | `role_villageois.png` |
| 113 | Voleur | `role_voleur.png` |
| 114 | Voyante | `role_voyante.png` |
| 116 | Juge | `role_juge.png` |

- Les textures font **512×512** (256 pour le Capitaine) : une taille qui n'est
  pas une puissance de 2 (les anciennes 785×785, 1254×1254 pour le Juge)
  désactive les mipmaps de *tout* le jeu pour les joueurs qui ont le pack. Les
  originaux sont gardés dans `_sources/textures/` (non inclus dans le zip).
- Les modèles (sauf Capitaine) définissent un affichage `head` : c'est ainsi
  que la carte d'un mort est posée au-dessus de sa porte et au-dessus du feu
  de camp (portée sur la tête d'un porte-armure invisible). La vue « en main »
  à la 3e personne reste volontairement à taille 0 pour qu'on ne voie jamais la
  carte d'un autre joueur.
